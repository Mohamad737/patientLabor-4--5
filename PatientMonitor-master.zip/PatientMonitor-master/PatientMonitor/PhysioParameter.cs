﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientMonitor
{
     class PhysioParameter
    {
        protected double amplitude = 0.0;
        protected double frequency = 0.0;

        protected int harmonics = 0;
        
        private double lowAlarm = 0;
        private double highAlarm = 0;
        private string lowAlarmString = " ";
        private string highAlarmString = " ";

        public PhysioParameter(double amplitude, double frequency, int harmonics, double lowAlarm, double highAlarm)
        {
            {
                this.amplitude = amplitude;
                this.frequency = frequency;
                this.harmonics = harmonics;
                this.lowAlarm = lowAlarm;
                this.highAlarm = highAlarm;
                displayLowAlarm(this.frequency, this.lowAlarm);
                displayHighAlarm(this.frequency, this.highAlarm);
            }
        }
        public double Amplitude { get => amplitude; set => amplitude = value; }
        public double Frequency { get => frequency; set => frequency = value; }
        public int Harmonics { get => harmonics; set => harmonics = value; }

        public string LowAlarmString { get { return lowAlarmString; } }
        public string HighAlarmString { get { return highAlarmString; } }
        
        public double LowAlarm { 
            get { return lowAlarm; }
            set { lowAlarm = value;
                displayLowAlarm(frequency, lowAlarm);
                displayHighAlarm(frequency, highAlarm);
            }
        }
        public double HighAlarm
        {
            get
            {
                return highAlarm;
            }
            set
            {
                highAlarm = value;
                displayLowAlarm(frequency, lowAlarm);
                displayHighAlarm(frequency, highAlarm);
            }
        }
        public void displayHighAlarm(double frequency, double alarmHigh)
        {
            if (frequency >= alarmHigh)
            {
                highAlarmString = "HIGH ALARM: " + frequency;
            }
            else
                highAlarmString = " ";
        }
        public void displayLowAlarm(double frequency, double alarmLow)
        {
            if (frequency <= alarmLow)
            {
                lowAlarmString = "LOW ALARM: " + frequency;
            }
            else
                lowAlarmString = " ";
        }








    }
}
