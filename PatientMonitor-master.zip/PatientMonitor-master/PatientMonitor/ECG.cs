﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientMonitor
{
    class ECG :PhysioParameter ,IPhysioFunctions
    {
       public ECG (double amplitude, double frequency , int harmonics ,double lowAlarm , double highAlarm) : base(amplitude, frequency, harmonics , lowAlarm,highAlarm) { }
    


    public double NextSample(double timeIndex , int harmonics)
        {
            const double HzToBeatsPerMin = 150.0;
            double sample = 0;

            switch (harmonics)
            {
                case 1:
                    sample = Math.Cos(2 * Math.PI * (frequency / HzToBeatsPerMin) * timeIndex);
                    break;
                case 2:
                    sample = Math.Cos(2 * Math.PI * (frequency / HzToBeatsPerMin) * timeIndex) + 0.5 * Math.Cos(2 * Math.PI * (2 * frequency / HzToBeatsPerMin) * timeIndex);
                    break;
                case 3:
                    sample = Math.Cos(2 * Math.PI * (frequency / HzToBeatsPerMin) * timeIndex) + 0.5 * Math.Cos(2 * Math.PI * (2 * frequency / HzToBeatsPerMin) * timeIndex) + 0.25 * Math.Cos(2 * Math.PI * (3 * frequency / HzToBeatsPerMin) * timeIndex);
                    break;

            }

            sample *= amplitude;

            return (sample);
        }
    }
}

