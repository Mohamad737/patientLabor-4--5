﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientMonitor
{
    internal class Patient
    {
        ECG ecg;
        EMG emg;
        EEG eeg;
        Resp resp;
        MRImages anImage;
        private string patientName;
        private DateTime dateOfStudy;
        private int age;
        MonitorConstants.Parameter parameter;
        private double activeFrequency = 0.0;
        private double activeAmplitude = 0.0;
        private int activeECGHarmonics = 0;
        private double activeLowAlarm =0.0;
        private double activeHighAlarm = 0.0;
        private string displayedHighAlarm = "";
        private string displayedLowAlarm = "";

        public double ECGAmplitude { get => ecg.Amplitude; set => ecg.Amplitude = value; }
        public double ECGFrequency { get => ecg.Frequency; set => ecg.Frequency = value; }

        public int ECGHarmonics { get => ecg.Harmonics; set => ecg.Harmonics = value; }
        public double ECGHighAlarm { get => ecg.HighAlarm; set => ecg.HighAlarm = value; }
        public double ECGLowAlarm { get => ecg.LowAlarm; set => ecg.LowAlarm = value; }
        public string PatientName { get => patientName; set => patientName = value; }

        public DateTime DateOfStudy { get => dateOfStudy; set => dateOfStudy = value; }
        public int Age { get => age; set => age = value; }
        public double EMGAmplitude { get => emg.Amplitude; set => emg.Amplitude = value; }
        public double EMGFrequency { get => emg.Frequency; set => emg.Frequency = value; }

        public double EMGHighAlarm { get => emg.HighAlarm; set => emg.HighAlarm = value; }
        public double EMGLowAlarm { get => emg.LowAlarm; set => emg.LowAlarm = value; }
        public double EEGAmplitude { get => eeg.Amplitude; set => eeg.Amplitude = value; }
        public double EEGFrequency { get => eeg.Frequency; set => eeg.Frequency = value; }
        public double EEGHighAlarm { get => eeg.HighAlarm; set => eeg.HighAlarm = value; }
        public double EEGLowAlarm { get => eeg.LowAlarm; set => eeg.LowAlarm = value; }
        public double RespAmplitude { get => resp.Amplitude; set => resp.Amplitude = value; }
        public double RespFrequency { get => resp.Frequency; set => resp.Frequency = value; }
        public double RespHighAlarm { get => resp.HighAlarm; set => resp.HighAlarm = value; }
        public double RespLowAlarm { get => resp.LowAlarm; set => resp.LowAlarm = value; }


        public MRImages AnImage { get => anImage; set => anImage = value; }
        public double ActiveLowAlarm { get => activeLowAlarm; }
        public double ActiveHighAlarm { get => activeHighAlarm; }
        public string DisplayedHighAlarm { get => displayedHighAlarm; }
        public string DislpayedLowAlarm { get => displayedLowAlarm; }

        public void setActiveParameters(double activeFrequency, double activeAmplitude, int activeECGHarmonics , double activeLowAlarm , double activeHighAlarm)
        {
            this.activeFrequency = activeFrequency;
            this.activeAmplitude = activeAmplitude;
            this.activeECGHarmonics = activeECGHarmonics;
            this.activeLowAlarm = activeLowAlarm;
            this.activeHighAlarm = activeHighAlarm;
        }
        public double ActiveAmplitude { get => activeAmplitude; }
        public double ActiveFrequency { get => activeFrequency; }
        public int ActiveECGHarmonics { get => activeECGHarmonics; }




        public Patient(double ampltude, double frequency, int harmonics, string patientName, DateTime dateOfStudy, int age ,  MRImages anImage, double lowAlarm ,double highAlarm)
        {
            this.patientName = patientName;
            this.dateOfStudy = dateOfStudy;
            this.age = age;
            this.anImage = anImage;
            
            ecg = new ECG(ampltude, frequency, harmonics ,lowAlarm,highAlarm);
            emg = new EMG(ampltude, frequency, harmonics,lowAlarm,highAlarm);
            eeg = new EEG(ampltude, frequency, harmonics,lowAlarm,highAlarm);
            resp = new Resp(ampltude, frequency, harmonics,lowAlarm,highAlarm);

        }
        public void LowAlarm(MonitorConstants.Parameter parameter , double alarmLow)
        {
            switch (parameter)
            {
                case MonitorConstants.Parameter.ECG:
                    ecg.LowAlarm = alarmLow;
                    displayedLowAlarm = ecg.LowAlarmString;
                    break;

                case MonitorConstants.Parameter.EEG:
                    eeg.LowAlarm = alarmLow;
                    displayedLowAlarm = eeg.LowAlarmString;
                    break;
                case MonitorConstants.Parameter.EMG:
                    emg.LowAlarm = alarmLow;
                    displayedLowAlarm = eeg.LowAlarmString;
                    break;
                case MonitorConstants.Parameter.Resp:
                    resp.LowAlarm = alarmLow;
                    displayedLowAlarm = resp.HighAlarmString;
                    break;

                default:
                    break;


            }

        }
        public void HighAlarm ( MonitorConstants.Parameter parameter , double alarmHigh)
        {
            switch(parameter)
            {
                case MonitorConstants.Parameter.ECG:
                    ecg.HighAlarm = alarmHigh;
                    displayedHighAlarm = ecg.HighAlarmString;
                    break;

                case MonitorConstants.Parameter.EEG:
                    eeg.HighAlarm = alarmHigh;
                    displayedHighAlarm = eeg.HighAlarmString;
                    break;

                case MonitorConstants.Parameter.EMG:
                    emg.HighAlarm = alarmHigh;
                    displayedHighAlarm = emg.HighAlarmString;
                    break;

                case MonitorConstants.Parameter.Resp:
                    resp.HighAlarm = alarmHigh;
                    displayedHighAlarm = resp.HighAlarmString;
                    break;

                default:
                    break;
            }

        }








        public void loadImages(string imageFile)
        {
            anImage.loadImages(imageFile);

        }
        public double NextSample(double timeIndex, MonitorConstants.Parameter parameter )
        {
            double nextSample = 0.0;
            switch (parameter)
            {
                case MonitorConstants.Parameter.ECG:
                    nextSample = ecg.NextSample(timeIndex , ecg.Harmonics);
                    break;

                case MonitorConstants.Parameter.EMG:
                    nextSample = emg.NextSample(timeIndex , emg.Harmonics);
                    break;

                case MonitorConstants.Parameter.EEG:
                    nextSample = eeg.NextSample(timeIndex , eeg.Harmonics);
                    break;
                default:
                    break;
                case MonitorConstants.Parameter.Resp:
                    nextSample = resp.NextSample(timeIndex , resp.Harmonics);
                    break;
            }
            return (nextSample);
        }
    }
}